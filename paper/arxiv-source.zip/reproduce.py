"""Rebuild the manuscript twice from loose source and twice from its source ZIP."""

import hashlib
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parent
MEMBERS = (
    "main.tex",
    "README.md",
    "reproduce.py",
    "anc/analytic/arithmetic.py",
    "anc/analytic/boxes.py",
    "anc/analytic/certificate.py",
    "anc/analytic/dominance.json",
    "anc/analytic/earlier-existence-note.md",
    "anc/analytic/effective-analytic-note.md",
    "anc/finite/generate.py",
    "anc/finite/intervals-287.json",
    "anc/finite/result-287.json",
    "anc/finite/verify.py",
)
EPOCH = "1795737600"


def compile_pdf(folder, executable, label):
    env = dict(os.environ, SOURCE_DATE_EPOCH=EPOCH, FORCE_SOURCE_DATE="1", TZ="UTC")
    for pass_num in (1, 2):
        run = subprocess.run(
            [executable, "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "main.tex"],
            cwd=folder,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        if run.returncode:
            raise RuntimeError(run.stdout.decode(errors="replace"))
        print(f"{label} pass {pass_num}: exit 0", flush=True)
    log = (folder / "main.log").read_text()
    warnings = re.findall(r"^(?:Overfull|Missing character|LaTeX Warning|Package \S+ Warning).*", log, re.M)
    if warnings:
        raise RuntimeError("\n".join(warnings))
    return (folder / "main.pdf").read_bytes()


def replay_certificates(folder):
    analytic = folder / "anc" / "analytic"
    for filename in ("boxes.py", "arithmetic.py", "certificate.py"):
        subprocess.run([sys.executable, "-IB", filename], cwd=analytic, check=True)
    subprocess.run(
        [
            sys.executable, "-IB", "-c",
            "import runpy; c = runpy.run_path('certificate.py'); "
            "assert c['tiny']()[1] < c['Q'](671, 1000); "
            "print('Exact endpoint phase loss < 671/1000: PASS')",
        ],
        cwd=analytic,
        check=True,
    )
    finite = folder / "anc" / "finite"
    result = subprocess.check_output(
        [sys.executable, "-IB", "verify.py", "intervals-287.json", "--max-old", "287"],
        cwd=finite,
    )
    if result != (finite / "result-287.json").read_bytes():
        raise RuntimeError("The finite verification output differs from the frozen result.")
    print("Finite verification output matches result-287.json", flush=True)



def main():
    local_tex = Path.home() / ".cache/spark-math-research/texlive/2026/bin/aarch64-linux/pdflatex"
    executable = os.environ.get("PDFLATEX") or shutil.which("pdflatex")
    if not executable and local_tex.is_file():
        executable = str(local_tex)
    if not executable:
        raise SystemExit("Install TeX Live 2026 or set PDFLATEX to its executable.")

    files = {name: (ROOT / name).read_bytes() for name in MEMBERS}
    with TemporaryDirectory(prefix=".threshold-four-build-", dir=ROOT) as work:
        folder = Path(work)
        loose = folder / "loose"
        archive_source = folder / "archive-source"
        loose.mkdir()
        archive_source.mkdir()
        archive = folder / "arxiv-source.zip"
        if len({name.casefold() for name in MEMBERS}) != len(MEMBERS):
            raise RuntimeError("Archive names collide on a case-insensitive filesystem.")
        with ZipFile(archive, "w") as zipped:
            for name, data in files.items():
                member = ZipInfo(name, (2026, 11, 27, 0, 0, 0))
                member.external_attr = 0o100644 << 16
                zipped.writestr(member, data, ZIP_DEFLATED)
                path = loose / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        with ZipFile(archive) as zipped:
            assert zipped.testzip() is None
            assert tuple(zipped.namelist()) == MEMBERS
            zipped.extractall(archive_source)
        assert all((archive_source / name).read_bytes() == data for name, data in files.items())
        pdf = compile_pdf(loose, executable, "loose source")
        assert compile_pdf(archive_source, executable, "source ZIP") == pdf
        replay_certificates(archive_source)
        staged = folder / "main.pdf"
        staged.write_bytes(pdf)
        staged.replace(ROOT / "main.pdf")
        archive.replace(ROOT / "arxiv-source.zip")

    print("Both clean builds produced the same PDF bytes. ZIP contents and CRCs checked.")
    for name in ("main.pdf", "arxiv-source.zip", *MEMBERS):
        data = (ROOT / name).read_bytes()
        print(f"{hashlib.sha256(data).hexdigest()}  {name}")


if __name__ == "__main__":
    main()
